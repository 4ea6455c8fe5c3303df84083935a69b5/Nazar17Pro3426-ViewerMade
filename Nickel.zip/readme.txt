███╗   ██╗██╗ ██████╗██╗  ██╗███████╗██╗        ███████╗██╗  ██╗███████╗
████╗  ██║██║██╔════╝██║ ██╔╝██╔════╝██║        ██╔════╝╚██╗██╔╝██╔════╝
██╔██╗ ██║██║██║     █████╔╝ █████╗  ██║        █████╗   ╚███╔╝ █████╗  
██║╚██╗██║██║██║     ██╔═██╗ ██╔══╝  ██║        ██╔══╝   ██╔██╗ ██╔══╝  
██║ ╚████║██║╚██████╗██║  ██╗███████╗███████╗██╗███████╗██╔╝ ██╗███████╗
╚═╝  ╚═══╝╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
                                                                        
Malware name: Nickel.exe
Malware type: Destructive
Created by: Nyfol2290
This is a skidded malware for you
This is a Win32.Kill.Trojan, it blocks the Task Manager and also changes the name of the windows to Nickel.exe