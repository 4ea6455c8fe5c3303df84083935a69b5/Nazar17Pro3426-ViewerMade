 ________   __ _____ _____  ______ _____  _____          _   _                
|  ____\ \ / // ____|  __ \|  ____|  __ \|_   _|   /\   | \ | |               
| |__   \ V /| (___ | |__) | |__  | |__) | | |    /  \  |  \| |  _____  _____ 
|  __|   > <  \___ \|  ___/|  __| |  _  /  | |   / /\ \ | . ` | / _ \ \/ / _ \
| |____ / . \ ____) | |    | |____| | \ \ _| |_ / ____ \| |\  ||  __/>  <  __/
|______/_/ \_\_____/|_|    |______|_|  \_\_____/_/    \_\_| \_(_)___/_/\_\___|

------------------------------------------------
✧ Information ✧
Developer: CYBERWARE
Coded in: C# & ASM
Version: 1.0
Category: Trojan-GDI.Win32
Compatible platforms: Windows 8.1, 10 & 11 (in 8.1 needs .NET Framework 4.0 to 4.8)
Modifies MBR? Yes
------------------------------------------------

⊗ Photosensitive seizure warning (example: epilepsy) ⊗
Includes specific graphic effects? Yes
Contains loud or intense audio? Yes

☢ Attention ☢
I (CYBERWARE) am not responsible for any damages or losses that may occur.

☞ Recommendation ☞
If you want to test for studies or ideas, I strongly recommend using Virtual Machines such as (VMware or VirtualBox).
------------------------------------------------

⇩ Networks ⇩
♤ YouTube: [CYBERWARE] (https://www.youtube.com/@CYBERWARE)
❀ GitHub: [CYBERWARE-SECURITY] (https://github.com/CYBERWARE-SEGURITY)
✯ Discord: t3nx1l
☁ My site: [CyberWareCursos] (https://linkfly.to/CyberWareCursos)