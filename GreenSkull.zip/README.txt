GreenSkull.exe

You opened me! Good for you!
You are about to run a dangerous trojan! If you open it, your computer will be destroyed.
Inspired by Scorpion Virus by ArabTEC :)
I added some GDI and Screen Of Rules.
----------------------------------------------------------------------------------------------------------------------------------
Combatibility: Windows XP SP1 and SP2 (x64)
To check your OS version, run check.bat in this pack.
It needs .NET Framework 4.0 or it will not work (correctly).
Download it here: https://www.microsoft.com/en-us/download/details.aspx?id=17718
----------------------------------------------------------------------------------------------------------------------------------
Coded with <3 by StarLae Tech.