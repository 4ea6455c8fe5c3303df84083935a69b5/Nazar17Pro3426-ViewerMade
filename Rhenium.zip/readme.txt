██████╗ ██╗  ██╗███████╗███╗   ██╗██╗██╗   ██╗███╗   ███╗   ███████╗██╗  ██╗███████╗
██╔══██╗██║  ██║██╔════╝████╗  ██║██║██║   ██║████╗ ████║   ██╔════╝╚██╗██╔╝██╔════╝
██████╔╝███████║█████╗  ██╔██╗ ██║██║██║   ██║██╔████╔██║   █████╗   ╚███╔╝ █████╗  
██╔══██╗██╔══██║██╔══╝  ██║╚██╗██║██║██║   ██║██║╚██╔╝██║   ██╔══╝   ██╔██╗ ██╔══╝  
██║  ██║██║  ██║███████╗██║ ╚████║██║╚██████╔╝██║ ╚═╝ ██║██╗███████╗██╔╝ ██╗███████╗
╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚═╝ ╚═════╝ ╚═╝     ╚═╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝

Rhenium was developed over the course of a few hours on November 9, 2024. It was made
by Nyfol2290 with the help by N17Pro3426 in C++, and is considered malware, because of
these destructive effects making the PC unusable without proper tools and tech knowledge.
Because of this, it's heavily recommended you don't run this on a real hardware, unless
you know how to repair these damaging effects.