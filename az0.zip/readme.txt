 █████╗ ███████╗   ███████╗██╗  ██╗███████╗
██╔══██╗╚══███╔╝   ██╔════╝╚██╗██╔╝██╔════╝
███████║  ███╔╝    █████╗   ╚███╔╝ █████╗  
██╔══██║ ███╔╝     ██╔══╝   ██╔██╗ ██╔══╝  
██║  ██║███████╗██╗███████╗██╔╝ ██╗███████╗
╚═╝  ╚═╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝

Malware name: az.exe
Created by: Nyfol2290 (only)
Malware type: Destructive
Description: This is a only GDI malware, NOT open the programs and moving windows, this is a Win32.Kill.Trojan