ini.exe (Trojan)
-------------------------------------------------------------------------------
1. What even is ini.exe?
ini.exe is a trojan horse made in C++. This is made only for educational
purposes. Do NOT try to prank anyone with it!

2. Is the malware safe?
Yes, but if it makes you think you are fucked. Do NOT panic! Just click
No if you are not brave.




idk what else to add...










-----------------------------------------------------------------------------
fun fact: I made this malware when I had the stomach flu... :< 