Back with another GDI malware.
Xrotonium.exe - NotCCR's last ever Purgatorium remake.

Malware type: GDI trojan
Works only on: Windows XP (on later OSes, it will crash right after the shake payload.)
Made by: NotCCR
Made in: C++
Creation date: 24th November 2024

This trojan can copy itself to the Internet Explorer Connection Wizard folder and make
itself run on startup, and can also mess up the labels!