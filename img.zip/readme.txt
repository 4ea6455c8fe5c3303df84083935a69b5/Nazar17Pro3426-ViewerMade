██╗███╗   ███╗ ██████╗    ███████╗██╗  ██╗███████╗
██║████╗ ████║██╔════╝    ██╔════╝╚██╗██╔╝██╔════╝
██║██╔████╔██║██║  ███╗   █████╗   ╚███╔╝ █████╗  
██║██║╚██╔╝██║██║   ██║   ██╔══╝   ██╔██╗ ██╔══╝  
██║██║ ╚═╝ ██║╚██████╔╝██╗███████╗██╔╝ ██╗███████╗
╚═╝╚═╝     ╚═╝ ╚═════╝ ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
                                                  
Malware name: img.exe
Malware type: Destructive
Skidded? No, it's not skidded!
Created by: FedouM
Description: This is a Win32.Kill.Trojan with the MBR! Thanks for watching readme!