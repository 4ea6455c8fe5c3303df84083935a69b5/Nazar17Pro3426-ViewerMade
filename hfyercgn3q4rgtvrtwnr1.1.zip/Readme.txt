hfyercgn3q4rgtfvrtwnr1.1.exe
My new updated malware!

Note: since the Scratch project was updated, also it's updated!
Here is the link to the Scratch project: https://scratch.mit.edu/projects/1017258661/