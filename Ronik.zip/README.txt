Ronik.exe
I am new with GDI!
Malware name: Ronik
It's beta & safety!
Have fun LOL!
Coded in C++ by metodej_the_coder.