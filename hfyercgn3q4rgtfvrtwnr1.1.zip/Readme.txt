hfyercgn3q4rgtfvrtwnr1.1.exe
My new malware, but updated!

Note: since the scratch project was updated, this is also updated!
Here's the link to the scratch project: https://scratch.mit.edu/projects/1017258661/